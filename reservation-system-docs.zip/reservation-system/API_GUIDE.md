# Reservation Management System — API Guide

Base path: `/api/v1`. Auth: Bearer JWT access token (`Authorization: Bearer <token>`), issued by `/auth/login`, refreshed via `/auth/refresh`. RBAC is enforced per-endpoint via permission codes (see role matrix in USER_GUIDE.md §3). All errors return `{"error": {"message": "...", ...}}` with an appropriate HTTP status.

## Quick Reference

| Method | Endpoint | Purpose | Auth | Permission |
|---|---|---|---|---|
| POST | /auth/register | Self-register (PENDING) | No | — |
| POST | /auth/login | Login, get tokens | No | — |
| POST | /auth/refresh | Rotate refresh token | No (refresh token) | — |
| POST | /auth/logout | Revoke refresh token | Yes | — |
| POST | /auth/change-password | Change own password | Yes | — |
| POST | /auth/password-reset/request | Request reset email | No | — |
| POST | /auth/password-reset/confirm | Complete reset | No | — |
| GET | /users | List users | Yes | user:manage |
| POST | /users | Create user (approved) | Yes | user:manage |
| GET | /users/{id} | Get user | Yes | user:manage |
| PATCH | /users/{id} | Update user | Yes | user:manage |
| DELETE | /users/{id} | Deactivate user | Yes | user:manage |
| POST | /users/{id}/approve | Approve/reject pending user | Yes | user:approve |
| GET | /products | List products | Yes | product:view |
| POST | /products | Create product | Yes | product:manage |
| GET | /products/{id} | Get product | Yes | product:view |
| PATCH | /products/{id} | Update product | Yes | product:manage |
| DELETE | /products/{id} | Delete product (blocked if setups exist) | Yes | product:manage |
| GET | /products/{id}/template | Get template (mandatory+custom columns) | Yes | product:view |
| POST | /products/{id}/template/columns | Add custom column | Yes | product:manage |
| PATCH | /products/{id}/template/columns/{col_id} | Edit custom column | Yes | product:manage |
| DELETE | /products/{id}/template/columns/{col_id} | Delete custom column | Yes | product:manage |
| POST | /products/{id}/template/columns/reorder | Reorder custom columns | Yes | product:manage |
| GET | /setups | List/filter setups | Yes | product:view |
| GET | /setups/{id} | Get setup | Yes | product:view |
| PATCH | /setups/{id} | Update setup | Yes | product:manage |
| DELETE | /setups/{id} | Delete setup | Yes | product:manage |
| GET | /setups/{id}/custom-fields | Get setup's custom field values | Yes | product:view |
| PUT | /setups/{id}/custom-fields | Set setup's custom field values | Yes | product:manage |
| POST | /reservations | Create reservation | Yes | reservation:create |
| GET | /reservations | List reservations | Yes | reservation:view |
| GET | /reservations/{id} | Get reservation | Yes | reservation:view |
| POST | /reservations/{id}/unreserve | Unreserve | Yes | reservation:manage_own or reservation:manage_all |
| POST | /swaps | Create swap | Yes | reservation:manage_own or reservation:manage_all |
| GET | /swaps | List swaps | Yes | reservation:view |
| GET | /swaps/{id} | Get swap | Yes | reservation:view |
| POST | /swaps/{id}/restore | Restore/undo swap | Yes | reservation:manage_all |
| GET | /announcements | List active announcements | Yes | — |
| POST | /announcements | Create announcement | Yes | announcement:manage |
| PATCH | /announcements/{id} | Update announcement | Yes | announcement:manage |
| DELETE | /announcements/{id} | Delete announcement | Yes | announcement:manage |
| GET | /groups | List groups | Yes | — |
| POST | /groups | Create group | Yes | group:manage |
| PATCH | /groups/{id} | Update group | Yes | group:manage |
| DELETE | /groups/{id} | Delete group | Yes | group:manage |
| POST | /imports/setups | Import Excel (legacy, all products) | Yes | import:run |
| POST | /imports/setups/product/{id}/detect-columns | Preview new columns in upload | Yes | import:run |
| POST | /imports/setups/product/{id} | Import Excel for one product | Yes | import:run (+product:manage if accepting new columns) |
| POST | /exports/setups | Export all setups | Yes | export:run |
| POST | /exports/setups/product/{id} | Export one product's setups (template-aware) | Yes | export:run |
| POST | /exports/setups/template | Export blank import template | Yes | export:run |
| GET | /audit-logs | List audit log entries | Yes | audit:view |

## Authentication

### POST /auth/register
Body: `{username, email, password, full_name, group_ids?}`. Creates a user in **PENDING** status. `password` must be 8+ chars with upper/lower/digit. Response: `UserResponse` (201). Audit: CREATE User.

### POST /auth/login
Body: `{username, password}`. Response: `{access_token, refresh_token, token_type}` (200). Errors: 401 invalid credentials, 403 pending/rejected/disabled account. Audit: LOGIN or LOGIN_FAILED.

### POST /auth/refresh
Body: `{refresh_token}`. Rotates the refresh token (old one revoked). Response: new token pair.

### POST /auth/logout
Body: `{refresh_token}`. Revokes it. Response: `MessageResponse`. Audit: LOGOUT.

### POST /auth/change-password
Auth required. Body: `{current_password, new_password}`. Revokes all existing sessions on success.

### POST /auth/password-reset/request
Body: `{email}`. Always returns the same generic message regardless of whether the email exists, to avoid user enumeration. Sends a single-use, 30-minute token via email if the account exists and is approved/active.

### POST /auth/password-reset/confirm
Body: `{token, new_password}`. 401 if token invalid/expired/used. Revokes all sessions on success.

## Users

Standard CRUD under `/users`, permission `user:manage`. `UserCreateRequest`/`UserUpdateRequest` accept `group_ids: List[int]` (multi-group; also sets the primary `group_id` to the first entry). `POST /users/{id}/approve` body `{approve: bool}` moves a PENDING user to APPROVED/REJECTED (permission `user:approve`); audit APPROVE/REJECT.

## Products

CRUD under `/products`, list is `product:view`, mutations `product:manage`. `DELETE /products/{id}` returns 409 (ConflictError) if any Setup still references it.

## Product Templates

Under `/products/{id}/template...`. `GET` returns `{product_id, mandatory_columns, custom_columns}`. Custom column fields: `name, label, data_type (STRING|INTEGER|FLOAT|BOOLEAN|DATE|DATETIME|DROPDOWN), required, default_value, allowed_values, order_index`. Mandatory columns can never be targeted by add/edit/delete/reorder (409/404 if attempted). Reorder body: `{column_ids: [...]}` (must include every existing custom column id exactly once).

## Setups

`GET /setups` supports filters: `product_id, group_id, status, location, search` + pagination. `PATCH /setups/{id}` updates any mandatory field (ip_address, hostname, owner_id, group_id, location, remarks, status, hardware fields); status changes go through a state-machine check. Custom field values are managed separately via `/setups/{id}/custom-fields` (`GET` returns `{setup_id, values}`; `PUT` body `{values: {...}}`, validated against the setup's product template — type-checked, required-field-checked, dropdown-value-checked; 422 on violation).

## Reservation

`POST /reservations` body: `{setup_ids: [...], reserved_from, reserved_until, remarks?, announcement_channels?}`. Validates each setup is AVAILABLE and the time window is valid. `POST /reservations/{id}/unreserve` blocked (409) if the setup has an active Swap. Both broadcast to `announcement_channels` (WALL, MAIL_LEADS, MAIL_GROUP, MAIL_ALL) via NotificationService.

## Swap

`POST /swaps` body: `{mappings: [{from_setup_id, to_setup_id}, ...], remarks?}`. Each mapping validated independently; a Swap record stores the full mapping set + status. `POST /swaps/{id}/restore` reverses a swap where supported by its current state (409 otherwise).

## Announcements

CRUD, `announcement:manage` for mutation; anyone authenticated can `GET` active ones. Fields: `title, message, priority (LOW|NORMAL|HIGH), start_date, end_date`.

## Groups

CRUD, `group:manage` for mutation. `DELETE` blocked if other data still depends on the group (per existing conflict checks in that service).

## Excel Import

- `POST /imports/setups` — legacy, unscoped import (headers must match the fixed `SETUP_IMPORT_COLUMNS` set, `product_name` column resolves the product per row).
- `POST /imports/setups/product/{id}/detect-columns` — multipart file upload; returns `{product_id, known_columns, new_columns, total_rows}` without importing.
- `POST /imports/setups/product/{id}?accept_new_columns=bool` — multipart file upload; validates against the product's template. If unknown columns are found and `accept_new_columns` is false, returns `committed=false` with `new_columns` populated and imports nothing. If true, adds the columns (as String type) to the template first, then imports. Response: `ImportResultResponse {batch_id, total_rows, created_count, updated_count, error_count, errors, committed, new_columns}`. Row errors block commit entirely (all-or-nothing). Audit: IMPORT per created/updated setup; transaction log rows written per row.

## Excel Export

- `POST /exports/setups` — all setups, fixed columns.
- `POST /exports/setups/product/{id}` — one product, mandatory + its current custom columns, in template order; empty header-only template if no setups exist yet.
- `POST /exports/setups/template` — blank import template (fixed columns only).

All return a downloadable `.xlsx` `FileResponse`. Audit: EXPORT.

## Logs / Audit

`GET /audit-logs` (`audit:view`): filter by `entity_type, entity_id, user_id, action` + pagination. Returns audit entries with actor, action, entity, old/new value snapshots, timestamp, IP where recorded. (Developer transaction-log download is web-only, not a JSON API — see `/admin/developer-logs` in the web app.)

## Status Codes (used throughout)

| Status | Meaning |
|---|---|
| 200 | Success |
| 201 | Created |
| 400/422 | Validation error |
| 401 | Authentication failed / invalid or expired token |
| 403 | Authenticated but not authorized (missing permission, account not approved/disabled) |
| 404 | Not found |
| 409 | Conflict (business rule violation, e.g. delete blocked, duplicate name) |
| 500 | Unhandled server error |

## Workflow Examples

- **Login → browse setups**: `POST /auth/login` → `GET /setups?product_id=1`
- **Reserve**: `GET /setups?product_id=1&status=AVAILABLE` → `POST /reservations`
- **Swap**: `POST /swaps` → later `POST /swaps/{id}/restore` to undo
- **Unreserve**: `POST /reservations/{id}/unreserve`
- **Design a template then import**: `POST /products/{id}/template/columns` (repeat) → `POST /imports/setups/product/{id}/detect-columns` → `POST /imports/setups/product/{id}?accept_new_columns=true`
- **Export current data**: `POST /exports/setups/product/{id}`
- **Approve a new user**: `GET /users?status=PENDING` → `POST /users/{id}/approve`
- **Forgot password**: `POST /auth/password-reset/request` → `POST /auth/password-reset/confirm`
